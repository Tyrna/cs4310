CS 4310 - Algorithms
Prof. Gupta

By: Oscar Vanderhorst

-------------------------------------

The following algorithm is written in python, to run using Python 3.

The program reads from input.txt following the standards given in the PDF.

Complexity analysis is in the .doc document.